#pragma once
#include"SFML\Graphics.hpp"

class Paddle //player class
{
public:
	Paddle();//constructor
	~Paddle();//destructor
	sf::RectangleShape getBody();//returns the shape
	void moveLeft();//decrements x value of position and sets position of the shape
	void moveRight();//increments x value of position and sets position of the shape
	sf::Vector2f getPos();//returns position

private:
	sf::RectangleShape m_body;//shape of our paddle
	sf::Vector2f m_position;//used to store the position of the paddle
};
