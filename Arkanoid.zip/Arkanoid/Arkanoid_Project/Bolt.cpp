#include"Bolt.h"

Bolt::Bolt()//constructor
{
	//initialise shape
	m_body.setFillColor(sf::Color::Cyan);
	m_body.setSize(sf::Vector2f(5, 5));
	m_body.setPosition(m_position);
}

Bolt::~Bolt()//destructor
{
}

sf::RectangleShape Bolt::getBody()//returns shape of projectile
{
	return m_body;
}

void Bolt::move()//adds the direction vector to position
{
	m_position += m_direction;
	m_body.setPosition(m_position);//sets position of the rectangleshape
}

void Bolt::checkWalls()//flips the direction when it hits a wall, multiplies the corresponding component of direction by -1
{
	if (m_position.x > 800)//if it hits right wall
	{
		m_position.x = 800;
		m_direction.x *= -1;
	}
	else if (m_position.x < 0)//if it hits left wall
	{
		m_position.x = 0;
		m_direction.x *= -1;
	}
	else if (m_position.y > 600)//if it hits bottom
	{
		m_position.y = 300;//resets position
		m_position.x = 300;
		spedUp = false;
	}
	else if (m_position.y <0)//if it hits top wall
	{
		m_position.y = 0;
		m_direction.y *= -1;
	}
}

void Bolt::flipDirectionY()//multiplies y component by -1
{
	m_direction.y *= -1;
}

void Bolt::flipDirectionX()//multiplies x component by -1
{
	m_direction.x *= -1;
}

void Bolt::increaseSpeed()//increases the speed of the projectile
{
	if (!spedUp)//if it hasn't been sped up
	{
		m_direction.x *= 2;//multiply direction by 2
		m_direction.y *= 2;
		spedUp = true;//set sped up to true
		remainingUses--;
	}
}

void Bolt::changeAngle(float Angle)//changes the angle of direction when it hits the paddle
{

	m_direction.x = cos(Angle * (acos(-1.0) / 180)) * speed; //cosine of the angle * PI / 180 to convert to radians
	m_direction.y = sin(Angle * (acos(-1.0) / 180)) * speed;//sine of the angle * PI / 180 to convert to radians
}

void Bolt::setPos(sf::Vector2f pos)//used to reset the position
{
	m_position = pos;//sets position vector to the passed argument
	m_body.setPosition(m_position);
}

int Bolt::getRemainingUses()
{
	return remainingUses;
}
