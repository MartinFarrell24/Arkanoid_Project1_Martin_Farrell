#pragma once
#include"SFML\Graphics.hpp"

class Brick //class for breakable blocks
{
public:
	Brick();//constructor
	~Brick();//destructor
	sf::RectangleShape getBody();//returns shape
	void setPosition(sf::Vector2f pos);//used to intialise arrays
	void initialise();//initialise everything except position
	void setAliveFalse();//kills block
	bool getAlive();//return bool for collision detection
	void setAliveTrue();//used to reset

private:
	sf::RectangleShape m_body;//shape
	bool alive = true;//bool for drawing and detection
};
