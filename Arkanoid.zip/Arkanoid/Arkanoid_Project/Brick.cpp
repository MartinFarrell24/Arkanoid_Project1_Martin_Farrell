#include"Brick.h"

Brick::Brick()//constructor
{
}

Brick::~Brick()//destructor
{
}

sf::RectangleShape Brick::getBody()//returns shape
{
	return m_body;
}

void Brick::setPosition(sf::Vector2f pos)//used to intialise arrays
{
	m_body.setPosition(pos);
}

void Brick::initialise()//initialise everything except position
{
	m_body.setFillColor(sf::Color::Yellow);
	m_body.setSize(sf::Vector2f(97, 50));
}

void Brick::setAliveFalse()//kills block
{
	alive = false;
}

bool Brick::getAlive()//return bool for collision detection
{
	return alive;
}

void Brick::setAliveTrue()
{
	alive = true;
}
