#pragma once
#include"SFML\Graphics.hpp"
class Bolt //class for projectile
{
public:
	Bolt();//constructor
	~Bolt();//destructor
	sf::RectangleShape getBody();//returns shape of projectile
	void move();//adds the direction vector to position
	void checkWalls();//flips the direction when it hits a wall, multiplies the corresponding component of direction by -1
	void flipDirectionY();//multiplies y component by -1
	void flipDirectionX();//multiplies x component by -1
	void increaseSpeed();//increases the speed of the projectile
	void changeAngle(float Angle);//changes the angle of direction when it hits the paddle
	void setPos(sf::Vector2f pos);//used to reset the position
	int getRemainingUses();

private:
	sf::RectangleShape m_body;//projectile
	sf::Vector2f m_direction{5, 5};//used to move the projectile
	sf::Vector2f m_position{ 300, 300 };//used to set the position of the projectile
	float speed = 5.0;//used for the angle change
	bool spedUp = false;//ensures projectile will only speed up once
	int remainingUses = 3;
};
