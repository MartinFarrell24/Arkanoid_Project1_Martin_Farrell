// author Martin Farrell

#include "Game.h"
#include <iostream>


//constructor
Game::Game() ://initialise window
	m_window{ sf::VideoMode{ 800, 600, 32 }, "Arkanoid" },
	m_exitGame{false} //when true game will exit
{
	//load font
	if (!m_font.loadFromFile("ASSETS\\FONTS\\ariblk.ttf"))
	{
	//error
	}

	//initialise strings
	m_gameOver.setString("Game Over \nPress r to reset");
	m_gameOver.setPosition(220, 250);
	m_gameOver.setCharacterSize(50);
	m_gameOver.setFillColor(sf::Color::Red);
	m_gameOver.setFont(m_font);

	m_timer.setPosition(10, 550);
	m_timer.setCharacterSize(15);
	m_timer.setFillColor(sf::Color::White);
	m_timer.setFont(m_font);

	m_speedUses.setPosition(450, 550);
	m_speedUses.setCharacterSize(15);
	m_speedUses.setFillColor(sf::Color::White);
	m_speedUses.setFont(m_font);
}


Game::~Game()//destructor
{
}


void Game::initialise()//intialise objects and such
{
	for (int i = 0; i < 8; i++)//intialise bricks
	{
		m_topBricks[i].setPosition(sf::Vector2f(100 * i, 80));
		m_topBricks[i].initialise();
		m_topBricks[i].setAliveTrue();
		m_bottomBricks[i].setPosition(sf::Vector2f(100 * i, 220));
		m_bottomBricks[i].initialise();
		m_bottomBricks[i].setAliveTrue();
	}
	//initialise enemies
	for (int i = 0; i < 6; i++)
	{
		m_topEnemies[i].setPosition(sf::Vector2f(100 * i + 100, 30));
		m_bottomEnemies[i].setPosition(sf::Vector2f(100 * i + 100, 160));
	}
	m_bolt.setPos(sf::Vector2f(300, 300));
	gameIsOver = false;
	count = 60;
}

void Game::run()//game loop
{
	//initialise everything
	initialise();

	sf::Clock clock;
	sf::Time timeSinceLastUpdate = sf::Time::Zero;
	sf::Time timePerFrame = sf::seconds(1.f / 60.f); // 60 fps
	while (m_window.isOpen())
	{
		processEvents(); // as many as possible
		timeSinceLastUpdate += clock.restart();
		while (timeSinceLastUpdate > timePerFrame)
		{
			timeSinceLastUpdate -= timePerFrame;
			processEvents(); // at least 60 fps
			update(timePerFrame); //60 fps
		}
		render(); //draw everything
	}
}
void Game::checkBrickCollision()//check if projectile collides with a brick
{
	if (m_bolt.getBody().getGlobalBounds().intersects(m_player.getBody().getGlobalBounds()))//if inside each other
	{
		checkPaddleCollision();
	}
	for (int i =0 ; i < 8; i++)
	{
		if (m_bolt.getBody().getGlobalBounds().intersects(m_bottomBricks[i].getBody().getGlobalBounds()))
		{
			
			if (m_bolt.getBody().getPosition().y > 210 && m_bottomBricks[i].getAlive() == true)
			{
				m_bolt.flipDirectionY();//changes direction if brick was alive
			}
			else if (m_bolt.getBody().getPosition().y < 160 && m_bottomBricks[i].getAlive() == true)
			{
				m_bolt.flipDirectionY();//changes direction if brick was alive
			}
			if (m_bolt.getBody().getPosition().x <= m_bottomBricks[i].getBody().getPosition().x && m_bottomBricks[i].getAlive() == true)
			{
				m_bolt.flipDirectionX();//changes direction if brick was alive
			}
			else if (m_bolt.getBody().getPosition().x >= m_bottomBricks[i].getBody().getPosition().x + 97 && m_bottomBricks[i].getAlive() == true)
			{
				m_bolt.flipDirectionX();//changes direction if brick was alive
			}
			m_bottomBricks[i].setAliveFalse();//deletes current brick if colliding
		}
		if (m_bolt.getBody().getGlobalBounds().intersects(m_topBricks[i].getBody().getGlobalBounds()))
		{

			if (m_bolt.getBody().getPosition().y > 210 && m_topBricks[i].getAlive() == true)
			{
				m_bolt.flipDirectionY();
			}
			else if (m_bolt.getBody().getPosition().y < 160 && m_topBricks[i].getAlive() == true)
			{
				m_bolt.flipDirectionY();
			}
			if (m_bolt.getBody().getPosition().x <= m_topBricks[i].getBody().getPosition().x && m_topBricks[i].getAlive() == true)
			{
				m_bolt.flipDirectionX();
			}
			else if (m_bolt.getBody().getPosition().x >= m_topBricks[i].getBody().getPosition().x + 97 && m_topBricks[i].getAlive() == true)
			{
				m_bolt.flipDirectionX();
			}
			m_topBricks[i].setAliveFalse();//deletes current brick if colliding
		}
	}
}

void Game::checkPaddleCollision()//check if projectile collides with the paddle
{
	deflectionAmount = (((m_bolt.getBody().getPosition().x + 5) - (m_player.getPos().x)) / 150 - 0.5);
	angle = 90 - (90 * abs(deflectionAmount));
	m_bolt.changeAngle(angle);
	m_bolt.flipDirectionY();
	/*if (m_bolt.getBody().getPosition().x + 5 > m_player.getBody().getPosition().x)
	{
		m_bolt.setPos(sf::Vector2f(m_bolt.getBody().getPosition().x, 544));
	}*/
}

void Game::checkInvaderCollision()
{
	for (int i = 0; i < 6; i++)
	{
		if (m_bolt.getBody().getGlobalBounds().intersects(m_topEnemies[i].getBody().getGlobalBounds()))
		{
			m_topEnemies[i].setAliveFalse();
		}
		if (m_bolt.getBody().getGlobalBounds().intersects(m_bottomEnemies[i].getBody().getGlobalBounds()))
		{
			m_bottomEnemies[i].setAliveFalse();
		}
	}
}

void Game::processEvents()
{
	sf::Event event;
	while (m_window.pollEvent(event))
	{
		if ( sf::Event::Closed == event.type) // window message
		{
			m_window.close();
		}
		if (sf::Event::KeyPressed == event.type) //user key press
		{
			if (sf::Keyboard::Escape == event.key.code)
			{
				m_exitGame = true;
			}
		}
	}
}

void Game::update(sf::Time t_deltaTime)
{
	m_timer.setString("time " + std::to_string(count));//sets string of timer to whatever count is
	m_speedUses.setString("Speed-Ups Remaining:" + std::to_string(m_bolt.getRemainingUses()));
	countCounter++;//increments each frame
	if (countCounter == 60)
	{
		count--;//increments every 60 frames
		countCounter = 0;//resets frame counter
		if (count == 0)//if time is up
		{
			gameIsOver = true;//change gamestate
		}
	}

	checkBrickCollision();//check for brick collisions
	checkInvaderCollision();//check invader collision
	if (m_exitGame)
	{
		m_window.close();
	}

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))//if left key pressed
	{
		m_player.moveLeft();//move paddle left
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))//if right key pressed
	{
		m_player.moveRight();//move paddle right
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))//if up key pressed 
	{
		if (m_bolt.getRemainingUses() > 0)
		{
			m_bolt.increaseSpeed();//increase speed
		}
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::R) && gameIsOver == true)//if up key pressed 
	{
		resetGame();
	}

	for (int i = 0; i < 6; i++)//loops through arrays
	{
		if (m_topEnemies[i].getBody().getPosition().x >= 780 && m_topEnemies[i].getAlive() == true)//if touching right side
		{
			for (int i = 0; i < 6; i++)
			{
				m_topEnemies[i].changeDirection();//flip direction
			}
		}
		else if (m_topEnemies[i].getBody().getPosition().x <= 0 && m_topEnemies[i].getAlive() == true)//if touching left side
		{
			for (int i = 0; i < 6; i++)
			{
				m_topEnemies[i].changeDirection();//flip direction
			}
		}
		if (m_bottomEnemies[i].getBody().getPosition().x >= 780 )//right side
		{
			for (int i = 0; i < 6; i++)
			{
				m_bottomEnemies[i].changeDirection();//flip direction
			}
		}
		else if (m_bottomEnemies[i].getBody().getPosition().x <= 0)//left side
		{
			for (int i = 0; i < 6; i++)
			{
				m_bottomEnemies[i].changeDirection();//flip direction
			}
		}
			m_topEnemies[i].move();
			m_bottomEnemies[i].move();
	}
		m_bolt.checkWalls();//check for wall collisions
		m_bolt.move();//move projectile

		for (int i = 0; i < 6; i++)
		{
			if (m_topEnemies[i].getAlive() == false)
			{
				gameOverCounter++;
			}
			if (m_bottomEnemies[i].getAlive() == false)
			{
				gameOverCounter++;
			}
		}
		if (gameOverCounter == 12)
		{
			gameIsOver = true;
		}
		else
		{
			gameOverCounter = 0;
		}
}


void Game::render()//draw everything
{
	
	if (!gameIsOver)//if the game is not over
	{
		m_window.clear();//clear window
		m_window.draw(m_player.getBody());//draw paddle

		for (int i = 0; i < 8; i++)//loops through bricks
		{
			if (m_topBricks[i].getAlive() == true)
			{
				m_window.draw(m_topBricks[i].getBody());//draws bricks
			}
			if (m_bottomBricks[i].getAlive() == true)
			{
				m_window.draw(m_bottomBricks[i].getBody());
			}
		}

		for (int i = 0; i < 6; i++)//loops through enemies
		{
			if (m_topEnemies[i].getAlive() == true)
			{
				m_window.draw(m_topEnemies[i].getBody());//draws enemies
			}
			if (m_bottomEnemies[i].getAlive() == true)
			{
				m_window.draw(m_bottomEnemies[i].getBody());
			}
		}
		m_window.draw(m_bolt.getBody());//draw projectile
		m_window.draw(m_timer);//draw timer message
		m_window.draw(m_speedUses);
		m_window.display();//display everything
	}
	else//if game state is over
	{
		m_window.clear();
		m_window.draw(m_gameOver);//draw game over text
		m_window.display();
	}

}

void Game::resetGame()
{
	initialise();
}
