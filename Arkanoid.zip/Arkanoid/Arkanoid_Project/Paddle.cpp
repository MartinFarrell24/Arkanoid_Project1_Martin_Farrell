#include"Paddle.h"

Paddle::Paddle()//constructor
{
	//initialise the shape
	m_body.setPosition(400, 550);
	m_body.setSize(sf::Vector2f(150, 15));
	m_body.setFillColor(sf::Color::Red);
}

Paddle::~Paddle()//destructor
{
}

sf::RectangleShape Paddle::getBody()//returns the shape
{
	return m_body;
}

void Paddle::moveLeft()//decrements x value of position and sets position of the shape
{
	sf::Vector2f pos = m_body.getPosition();//used to store previous position pre-decrement
	pos.x -=5;
	if (pos.x <= 0)//prevents paddle from going past the left-most side of the window
	{
		pos.x = 0;
	}
	m_body.setPosition(pos);//sets position of the shape

}

void Paddle::moveRight()//increments x value of position and sets position of the shape
{
	sf::Vector2f pos = m_body.getPosition();//used to store previous position post-decrement
	pos.x += 5;
	if (pos.x >= 800-150)//prevents paddle from going past the right-most side of the window
	{
		pos.x = 800-150;
	}
	m_body.setPosition(pos);//sets position of the shape
}

sf::Vector2f Paddle::getPos()
{
	m_position = m_body.getPosition();//assigns current position of shape to our member vector
	return m_position;
}


