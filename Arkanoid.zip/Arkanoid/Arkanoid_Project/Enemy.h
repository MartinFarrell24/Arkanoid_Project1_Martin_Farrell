#pragma once
#include"SFML\Graphics.hpp"

class Enemy//space invader class
{
public:
	Enemy();//constructor
	~Enemy();//destructor
	sf::RectangleShape getBody();//returns shape
	void setPosition(sf::Vector2f pos);//used to intialise arrays of enemies
	void move();//moves the enemies left and right
	void changeMovingBool();//flip movement bool, changing direction
	void changeDirection();
	void setAliveFalse();
	void setAliveTrue();
	bool getAlive();

private:
	sf::RectangleShape m_body;//shape of the invaders
	bool moving = true;//used for movement
	bool alive = true;
	sf::Vector2f m_position;
	float direction = 0.5;
};
