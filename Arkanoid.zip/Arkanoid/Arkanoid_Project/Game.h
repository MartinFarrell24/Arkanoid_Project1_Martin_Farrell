// author Martin Farrell
#ifndef GAME
#define GAME

#include <SFML/Graphics.hpp>
#include"Paddle.h"
#include"Brick.h"
#include"Enemy.h"
#include"Bolt.h"
class Game
{
public:
	Game();//constructor
	~Game();//destructor
	void initialise();//intialise objects and such
	void run();//game loop
	void checkBrickCollision();//check if projectile collides with a brick
	void checkPaddleCollision();//check if projectile collides with the paddle
	void checkInvaderCollision();
	void processEvents();//process input
	void update(sf::Time t_deltaTime);//update variables
	void render();//draw everything
	void resetGame();
private:

	sf::Font m_font;//used to store font
	sf::Text m_gameOver;//text used for game over screen
	sf::Text m_timer;//used to display the timer
	sf::Text m_speedUses; //text for power up uses
	sf::RenderWindow m_window; // main SFML window
	bool m_exitGame; // control exiting game
	Paddle m_player;//instance of paddle player controls
	Brick m_topBricks[8];//top row of bricks
	Brick m_bottomBricks[8];//bottom row of bricks
	Enemy m_topEnemies[6];//top row of enemies
	Enemy m_bottomEnemies[6];//bottom row of enemies
	Bolt m_bolt;//projectile
	float deflectionAmount;//used in angle calc
	float angle;//stores angle calculated
	bool gameIsOver = false;//used to change states once time is up
	int count = 45;//decremented to reach game over
	int countCounter = 0;//increments count every time it reaches 60(increments each frame)
	int gameOverCounter = 0;
};

#endif // !GAME

