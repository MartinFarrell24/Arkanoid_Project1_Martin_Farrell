#include"Enemy.h"

Enemy::Enemy()//constructor
{
	m_body.setFillColor(sf::Color::Magenta);
	m_body.setSize(sf::Vector2f(20, 20));
}

Enemy::~Enemy()//destructor
{
}

sf::RectangleShape Enemy::getBody()//returns shape
{
	return m_body;
}

void Enemy::setPosition(sf::Vector2f pos)//used to intialise arrays of enemies
{
	m_position = pos;
	m_body.setPosition(m_position);
}

void Enemy::move()//moves the enemies left and right
{
	m_position.x = m_position.x + direction;//decrements x postion
	m_body.setPosition(m_position); //assigns new postion
}

void Enemy::changeMovingBool()//flip movement bool, changing direction
{
	if (moving)//if true
	{
		moving = false;//make false
	}
	else//if false
	{
		moving = true;//make true
	}
}

void Enemy::changeDirection()
{
	direction = direction * -1;
}

void Enemy::setAliveFalse()
{
	alive = false;
}

void Enemy::setAliveTrue()
{
	alive = true;
}

bool Enemy::getAlive()
{
	return alive;
}
